import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart';
import 'package:trustwise_app/slider_widget.dart';
import 'package:velocity_x/velocity_x.dart';
import 'package:web3dart/web3dart.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TrustWise',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(title: 'TrustWise'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  Client httpClient;
  Web3Client ethClient;
  bool data = false;
  int myAmount = 0;

  final myAddress = "0x3cA34eF0271a3E4e4218262427232b0A92d9E914";

  String txHash;

  var myData;

  // For connecting the app to the server

  @override
  void initState() {
    super.initState();
    httpClient = Client();
    ethClient = Web3Client(
        "https://rinkeby.infura.io/v3/9adc6040b6c040ebbd0540bcd5c1ca8e",
        httpClient);
    getBalance(myAddress);
  }

  // For fetching the deployed contract's data and loading contract

  Future<DeployedContract> loadContract() async {
    String abi = await rootBundle.loadString("assets/abi.json");
    String contractAddress = "0x7E0209cB5B1235bB261fE94BF91A42b89f0433c2";

    final contract = DeployedContract(ContractAbi.fromJson(abi, "trustwise"),
        EthereumAddress.fromHex(contractAddress));

    return contract;
  }

  // For firing query to the abi.json, making calls and fetching the response

  Future<List<dynamic>> query(String functionName, List<dynamic> args) async {
    final contract = await loadContract();
    final ethFunction = contract.function(functionName);
    final result = await ethClient.call(
        contract: contract, function: ethFunction, params: args);

    return result;
  }

  // For fetching the balance

  Future<void> getBalance(String targetAddress) async {
    // EthereumAddress address = EthereumAddress.fromHex(targetAddress);
    List<dynamic> result = await query("getBalance", []);

    myData = result[0];
    data = true;
    setState(() {});
  }

  // For Submiting the result

  Future<String> submit(String functionName, List<dynamic> args) async {
    EthPrivateKey credentials = EthPrivateKey.fromHex(
        "11dfbcfa86fd43be90cb67987f81cc0f40780dadaec09c928eb614e147b982ba");

    DeployedContract contract = await loadContract();

    final ethFunction = contract.function(functionName);
    final result = await ethClient.sendTransaction(
        credentials,
        Transaction.callContract(
            contract: contract, function: ethFunction, parameters: args),
        fetchChainIdFromNetworkId: true);
    return result;
  }

  // For Depositing
  Future<String> sendCoin() async {
    var bigAmount = BigInt.from(myAmount);

    var response = await submit("depositBalance", [bigAmount]);

    print("Deposited");
    txHash = response;
    setState(() {});

    return response;
  }

  // For Withdrawing
  Future<String> withdrawCoin() async {
    var bigAmount = BigInt.from(myAmount);

    var response = await submit("withdrawBalance", [bigAmount]);

    print("Withdrawn");
    txHash = response;
    setState(() {});

    return response;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Vx.gray900,
      body: ZStack([
        VxBox()
            .purple900
            .size(context.screenWidth, context.percentHeight * 30)
            .make(),
        VStack([
          (context.percentHeight * 10).heightBox,
          "\<(( TRUSTWISE ))>"
              .text
              .xl4
              .widest
              .white
              .extraBold
              .center
              .makeCentered()
              .py16(),
          (context.percentHeight * 5).heightBox,
          VxBox(
                  child: VStack([
            "TRUST WALLET".text.gray900.xl3.bold.makeCentered(),
            40.heightBox,
            data
                ? "\₹$myData".text.bold.xl6.makeCentered().shimmer(
                    primaryColor: Colors.indigo[900],
                    secondaryColor: Colors.yellow[300])
                : CircularProgressIndicator(
                    backgroundColor: Colors.red[300],
                  ).centered()
          ]))
              .p16
              .green300
              .size(context.screenWidth, context.percentHeight * 23)
              .roundedLg
              .shadowXl
              .make()
              .p16(),
          80.heightBox,
          SliderWidget(
              min: 0,
              max: 100,
              finalVal: (value) {
                myAmount = (value * 100).round();
                print(myAmount);
              }).centered(),
          80.heightBox,
          HStack([
            FlatButton.icon(
                    onPressed: () => withdrawCoin(),
                    color: Colors.deepOrange,
                    shape: Vx.roundedLg,
                    icon: Icon(
                      Icons.call_received_outlined,
                      color: Colors.white,
                    ),
                    label: "WITHDRAW".text.white.make())
                .h(50),
            FlatButton.icon(
                    onPressed: () => getBalance(myAddress),
                    color: Colors.indigo,
                    shape: Vx.roundedLg,
                    icon: Icon(
                      Icons.refresh,
                      color: Colors.white,
                    ),
                    label: "REFRESH".text.white.make())
                .h(50),
            FlatButton.icon(
                    onPressed: () => sendCoin(),
                    color: Colors.orange,
                    shape: Vx.roundedLg,
                    icon: Icon(
                      Icons.call_made_outlined,
                      color: Colors.white,
                    ),
                    label: "DEPOSIT".text.white.make())
                .h(50),
          ],
                  alignment: MainAxisAlignment.spaceBetween,
                  axisSize: MainAxisSize.max)
              .p16(),
          if (txHash != null) txHash.text.white.makeCentered().shimmer().p16(),
        ])
      ]),
    );
  }
}
