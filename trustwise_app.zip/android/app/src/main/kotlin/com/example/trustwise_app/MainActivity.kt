package com.example.trustwise_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
